import java.util.Arrays;
import java.util.Random;


public class ANN {
	
	public static double [][]X={
		{0.0,0.0},
		{0.0,1.0},
		{1.0,0.0},
		{1.0,1.0}
	};
	
	public static double[] y={
		0.0,
		1.0,
		1.0,
		0.0};
	
	public static double[][] hiddenWeights
	= new double[2][3];/*{
		{-5.0,10.0,-10.0},
		{-5.0,-10.0,10.0}
	};*/
	public static double [] outputWeights
	= new double[3];/*{-5.0,10.0,10.0};*/
	
	
	public static Random rnd = new Random();
	
	public static double activation(double z)
	{
		//return z>0?1:0;
		return 1.0/(1+Math.exp(-1.0*z));
		
	}
	public static double feedForward(double [] x)
	{
		double outputNH0 = 
				hiddenWeights[0][0]+
				hiddenWeights[0][1]*x[0]+
				hiddenWeights[0][2]*x[1];
		double outputNH1 = 
				hiddenWeights[1][0]+
				hiddenWeights[1][1]*x[0]+
				hiddenWeights[1][2]*x[1];
		double outputNHA0=activation(outputNH0);
		double outputNHA1=activation(outputNH1);
		
		double outputNHF0=
				outputWeights[0]+
				outputWeights[1]*outputNHA0+
				outputWeights[2]*outputNHA1;
		double output = activation(outputNHF0);
		return output;
		
		
	}
	
	public static void main(String... args)
	{
		learn();
		for (double[] x : X) {
			System.out.println(feedForward(x));
		}
		
		for (double [] x : hiddenWeights) {
			System.out.println(Arrays.toString(x));
		}
		System.out.println(Arrays.toString(outputWeights));
		
		
	}
	
	public static void learn()
	{
		for(int i=0;i<hiddenWeights.length;i++)
			for(int j=0;j<hiddenWeights[0].length;j++)
				hiddenWeights[i][j]=-10+rnd.nextDouble()*20;
		for(int i =0;i<outputWeights.length;i++)
			outputWeights[i]=-10+rnd.nextDouble()*20;
	}

}
