import javax.swing.*;

import java.awt.*;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Random;

/**
 * Created by swakkhar on 4/10/17.
 */
public class NaiveBayes {
	public static Random rnd = new Random();
    public static int X[][]=new int [5000][400];
    public static int y[] = new int[5000];
    public static void readData() throws IOException {
        BufferedReader readerX = new BufferedReader(new FileReader("X.csv"));
        BufferedReader readerY = new BufferedReader(new FileReader("Y.csv"));
        String xStr=null;
        String yStr=null;
        int i=0;
        while (true)
        {
            xStr=readerX.readLine();
            yStr=readerY.readLine();
            if (xStr==null)break;

            int j=0;
            for (String x:xStr.split(",")) {
                X[i][j]=Integer.parseInt(x);
                j++;
            }
            y[i]=Integer.parseInt(yStr);
            i++;

        }
    }

    public static void main(String[] args) throws IOException {
        readData();
        int index=rnd.nextInt(5000);
        System.out.println(index);
        new DigitDisplay(X[index]);
        System.out.println("Real Label:"+y[index]);
        System.out.println("Predicted Label:"+predictData(X[index]));
    }
    
    public static int predictData(int[] x)
    {
    	return -1;
    }
}


class DigitDisplay extends JFrame
{
    int [][] data= new int[20][20];
    public DigitDisplay(int [] d)
    {
        super("Digit Display");
        for(int i=0;i<20;i++)
            for(int j=0;j<20;j++)
                data[i][j]=d[i*20+j];
        setSize(400,400);
        setVisible(true);
    }
    public void paint(Graphics g)
    {
        for(int i=0;i<20;i++)
            for(int j=0;j<20;j++)
            {
                if(data[i][j]==1)
                    g.fillRect(i*20,j*20,20,20);
            }
    }
}
